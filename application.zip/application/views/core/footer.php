</body>

<footer id="footer">
     <div class="container-fluid" style="background:#1a374a; padding:10px; color:white;">
        <div class="container">
            <div class="row">
            <div class="col-md-6">
                <br>
                <h5 style="color: #ffffff"> AVKMO </h5>
                <hr class="line mt-0 mx-0">
                <p style="color: #ffffff">
                    AVKMO adalah aplikasi berbasis online untuk memilih ketua mpk dan osis di SMK Negeri 2 Sumedang.
                </p>
            </div>
            <div class="col-md-6">
                <br>
                <h5 style="color: #ffffff; text-align: center;"> SUPPORT </h5>
                <hr class="line mt-0 mx-0">
                <img class="logo" src="<?=base_url()?>resources/img/logo smk.png">
                <img class="logo" src="<?=base_url()?>resources/img/rpl.png">
                <img class="logo" src="<?=base_url()?>resources/img/logo mpk.png">
                <img class="logo" src="<?=base_url()?>resources/img/logo_osis.png">
            </div>
            </div>
        </div>
    </div>
    <div class="container-fluid" style="background: #152b3a;padding: 10px;color:white;">
            <div class="row justify-content-center">
                <div class="col-11 col-md-5 col-lg-5">
                    <p style="text-align: center; margin: 0px;">2020 © Aplikasi Voting Ketua MPK dan OSIS</p>
                </div>
            </div>
    </div>
</footer>

</div><!-- div#containerjuga -->
    <script src="<?=base_url()?>resources/js/jquery-3.2.1.min.js"></script>
    <script src="<?=base_url()?>resources/js/popper.min.js"></script>
    <script src="<?=base_url()?>resources/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?=base_url()?>resources/datatables/jquery.dataTables.min.js"></script>
    <script src="<?=base_url()?>resources/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="<?=base_url()?>resources/js/main.js?v=1.53"></script>
    <script src="<?=base_url()?>resources/select2/dist/js/select2.min.js" ></script>
    
    <?php /*
    <script src="<?=base_url()?>resources/bootstrap-confirmation-2/bootstrap-confirmation.js"></script>
    */ ?>

    <script>
        $(document).ready(function() {
                $('.select2').select2();
            });
        $('.notifications').slideDown('slow').delay(3000).slideUp('slow');
    </script>
</html>