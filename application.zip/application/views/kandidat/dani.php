<div class="container-fluid">
	<div class="row justify-content-center">
		<div class="col-6">
			<img src="<?=base_url()?>resources/img/logo.jpeg" width="100%" height="auto">
		</div>
	</div>
	<div class="row justify-content-center">
		<div class="col-12" style="text-align: center;">
			<h4>Nama : Dani Nugraha</h4>
		</div>
	</div>
	<div class="row justify-content-center">
		<div class="col-12 " style="text-align: center;">
			<h4>Kelas : XI-RPL 1</h4>
		</div>
	</div>
	<div class="row">
		<div class="col-12">
			<h4>Visi :</h4>
		</div>
	</div>
	<div class="row">
		<div class="col-12">
			<p>.........</p>
		</div>
	</div>
	<div class="row">
		<div class="col-12">
			<h4>Misi :</h4>
		</div>
	</div>
	<div class="row">
		<div class="col-12">
			<p>.........</p>
		</div>
	</div>
</div>