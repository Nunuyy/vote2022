
<div id="body">
  <div class="row align-items-center">
    <div class="col-md-3"></div>
    <div class="col-md-6">

<div class="alert alert-danger text-center" role="alert">
  <h4 class="alert-heading"><h2>Pemberitahuan</h2></h4>
  	<hr>
  <h4>
    <p>Anda sudah memilih ketua MPK</p>
  	<p>Lanjutkan untuk memilih Ketua OSIS. <br>
  	</p>
  	<a class="btn btn-primary btn-lg" href="<?=base_url('/guru/osis')?>" role="button">Lanjutkan</a>
  </h4>
</div>

    </div>
    <div class="col-md-3"></div>
  </div>
</div><!-- div#body -->
</body>
