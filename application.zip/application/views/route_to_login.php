<html>
<head>
<style type="text/css">
    .login {
        margin: 250px auto;
        width: 900px;
        padding: 10px;
		color:#FF0

    }
	.h {
		font-family:Verdana, Geneva, sans-serif;
		color:#FF0;
		}
	</style>
</head>
<body style="background-color: #083c5f;" >
	<div class="row justify-content-center" style="padding-right:15px; padding-left:15px;">
        <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
	      <h1 class="display-5" style="color: #ffa826; font-weight: normal;" ><strong>Aplikasi Voting Ketua OSIS dan MPK</strong></h1>
	      <h2 class="display-5" style="color: #ffa826; font-weight: normal;" >LOGIN SEBAGAI</h2>
	    </div>
    </div>
	<div class='row justify-content-center'  style="padding-right:15px; padding-left:15px;">
		<div class="container">
	      <div class="card-deck mb-3 text-center">
	        <div class="card mb-4 shadow-sm">
	          <div class="card-header">
	            <h4 class="my-0 bold">Siswa</h4>
	          </div>
	          <div class="card-body">
	            <h1 class="card-title pricing-card-title"><img src="<?php echo base_url();?>resources/img/siswa.png" alt="" width="256px"></h1>
	            <a href="login" type="button" class="btn btn-lg btn-block btn-primary">Ke Halaman Login</a>
	          </div>
	        </div>
	        <div class="card mb-4 shadow-sm">
	          <div class="card-header">
	            <h4 class="my-0 bold">Guru</h4>
	          </div>
	          <div class="card-body">
	            <h1 class="card-title pricing-card-title"><img src="<?php echo base_url();?>resources/img/guru.png" alt="" width="256px"></h1>
	            <a href="Login/login_guru" type="button" class="btn btn-lg btn-block btn-primary">Ke Halaman Login</a>
	          </div>
	        </div>
	        <div class="card mb-4 shadow-sm">
	          <div class="card-header">
	            <h4 class="my-0 bold">Tenaga Kependidikan</h4>
	          </div>
	          <div class="card-body">
	            <h1 class="card-title pricing-card-title"><img src="<?php echo base_url();?>resources/img/tendik.png" alt="" width="256px"></h1>
	            <a href="Login/login_tendik" type="button" class="btn btn-lg btn-block btn-primary">Ke Halaman Login</a>
	          </div>
	        </div>
	      </div>
	    </div>
	</div>
	<br><br><br><br><br><br><br><br>
</body>
</html>