var baseUrlGlobal = $('#base_url').val();

$(document).ready(function(){

    $('.datatablesGeneral').DataTable();

});